# Opciones 
options(scipen = 999)
Sys.setlocale("LC_ALL", "es_ES.UTF-8") # Cambiar locale para prevenir problemas con caracteres especiales

# Librerias para manejar archivos geograficos
library(sf)
library(tidyverse)
library(viridis)
library(readr)
library(dplyr)
library(pacman)
p_load(tidyverse, 
       plotly, 
       readxl, 
       scales)
library(leaflet) # Visualización interactiva (mapas)
library(tidyverse) # Manejo de bases de datos
library(htmlwidgets) # Para guardar paginas HTML
library(webshot) # Para imprimir paginas HTML

#Bases de Datos
mapa_dtos_nl <- st_read("01_Datos/NuevoLeon/DISTRITO.shp", quiet = T)%>% 
                st_transform(crs = 4326) 
data_dtos <- read_delim("01_Datos/diputaciones.csv", 
                           "|", escape_double = FALSE, trim_ws = TRUE, 
                           skip = 5) 

class(mapa_dtos_nl)
# Checamos que tenga lo que queremos
plot(mapa_dtos_nl, max.plot = 1)

data_NL<- 
  data_dtos %>% 
  filter(ID_ESTADO == "19" & LISTA_NOMINAL_CASILLA > "0") %>% 
  group_by(ID_DISTRITO,NOMBRE_DISTRITO) %>% 
  mutate(ABST = TOTAL_VOTOS_CALCULADOS/LISTA_NOMINAL_CASILLA) %>% 
  summarise(ausentismo = mean(ABST, na.rm=FALSE),
            v_MORENA=sum(sum(MORENA)),
            v_PAN=sum(sum(PAN)),
            V_PRI=sum(sum(PRI))) %>%
  mutate(ganador = ifelse(v_PAN>V_PRI & v_PAN>v_MORENA, 
                          "PAN",
                          ifelse(V_PRI>v_PAN & V_PRI>v_MORENA,
                                 "PRI",
                                 "MORENA"))) %>% 
  view()



# data_NL<- 
#   data_dtos %>% 
#   filter(ID_ESTADO == "19" & LISTA_NOMINAL_CASILLA > "0") %>% 
#   group_by(ID_DISTRITO,NOMBRE_DISTRITO) %>% 
#   mutate(ABST = TOTAL_VOTOS_CALCULADOS/LISTA_NOMINAL_CASILLA) %>% 
#   summarise(ausentismo = mean(ABST, na.rm=FALSE),
#                 v_MORENA=sum(sum(MORENA),sum(PT), sum(`ENCUENTRO SOCIAL`)),
#             v_PAN=sum(sum(PAN),sum(`MOVIMIENTO CIUDADANO`),sum(PRD)),
#             V_PRI=sum(sum(PRI),sum(PVEM),sum(`NUEVA ALIANZA`))) %>%
#   mutate(ganador = ifelse(v_PAN>V_PRI & v_PAN>v_MORENA, 
#                           "PAN",
#                           ifelse(V_PRI>v_PAN & V_PRI>v_MORENA,
#                                  "PRI",
#                                  "MORENA"))) %>% 
#   view()

#Gráfica de abstencionismo por distrito en Nuevo León

glimpse(data_NL)

Nombres <- as_tibble(c("Santa Catarina", "Apodaca", "Escobedo", "San Nicolás","Monterrey 1", "Monterrey 2", "García", "Guadalupe", "Linares", "Monterrey 3", "Guadalupe 2", "Juárez")) 

data_NL<-
  data_NL %>% 
  bind_cols(Nombres) %>% 
  rename(NOMBRES=value) %>% 
  select(-NOMBRE_DISTRITO)

names(data_NL)
  
#1 GRÁFICA

GF<-data_NL%>% 
  ggplot()+
  geom_point(aes(x=v_PAN, y=ausentismo))+
labs(title = str_wrap("Relación entre los votos obtenidos por el PAN 
                      y el abstencionismo en la elección al Congreso Federal 
                      en Nuevo León en 2018", width = 50),
     subtitle = "Cada punto representa un distrito.",
     x = "Votos recibidos por el PAN",
     y = "Radio de abstencionismo") +
  theme_minimal() +
  theme(panel.grid.minor = element_blank(), 
        panel.grid.major = element_line(linetype = "dashed"),
        axis.title = element_text(size = 12, hjust = 1, color = "#a50f15", face = "bold"),
        axis.title.x = element_text(margin = margin(15, 0, 0, 0)),
        axis.title.y = element_text(margin = margin(0, 15, 0, 0)))

plot(GF)
#2 MAPA ESTÁTICO

Mapa_NL <- merge(x=mapa_dtos_nl,
                 y=data_NL,
                 by.x="id",
                 by.y="ID_DISTRITO",
                 all.y=TRUE)
class(Mapa_NL)
plot(Mapa_NL,max.plot = 1)

MF<- Mapa_NL%>% 
  ggplot()+ 
  geom_sf(aes(fill=ganador))+
  scale_fill_manual(values=c("#8A2429","#1747C7","#076307"))+
labs(title = "¿Quién va al Congreso Federal?",
     subtitle = "Año: 2018", 
     caption = "Fuente: INE") + 
  theme_bw() + 
  theme(legend.position = "bottom") + 
  theme(axis.text = element_blank(), 
        panel.grid = element_blank(), 
        panel.border = element_blank(), 
        panel.background = element_rect(),
        axis.ticks = element_blank()) + 
  theme(plot.title = element_text(hjust = 0.5, 
                                  colour = "gray10", 
                                  family = "Arial", 
                                  face = "bold", 
                                  size = 15), 
        plot.subtitle = element_text(hjust = 0.5, 
                                     colour = "gray50", 
                                     family = "Arial", 
                                     face = "bold", 
                                     size = 15), 
        plot.caption = element_text(colour = "gray50", 
                                    hjust = 1))


#GRÁFICA DINÁMICA

GD<-data_NL%>% 
  ggplot()+
  geom_point(aes(x=v_PAN, y=v_MORENA, color=ganador))+
  labs(
       x = "Votos recibidos por el PAN",
       y = "Votos recibidos por MORENA",
       color = "¿Quién ganó?") +
  theme(panel.grid.minor = element_blank(), 
        panel.grid.major = element_line(linetype = "dashed"),
        axis.title = element_text(size = 10, hjust = 4, color = "#a50f15", face = "bold"),
        axis.title.x = element_text(margin = margin(15, 0, 0, 0)),
        axis.title.y = element_text(margin = margin(0, 15, 0, 0)),
        legend.position = "right",
        legend.title = element_text(size=10))
ggplotly()


#MAPA DINÁMICO

leaflet(Mapa_NL) %>% 
  addPolygons()

#Hacemos la paleta de colores
pal <- colorFactor(palette=c("#8A2429","#1747C7","#076307"), domain = Mapa_NL$ganador)
#Hacemos el popup
popup <- paste0("<b>Distrito no. : </b>", Mapa_NL$id, "<br>",
                  "<b>Nombre: </b>", Mapa_NL$NOMBRES , "<br>",
                  "<b>Votos del PAN: </b>", Mapa_NL$v_PAN, "<br>",
                  "<b>Votos del PRI: </b>", Mapa_NL$V_PRI , "<br>",
                  "<b>Votos de MORENA: </b>", Mapa_NL$v_MORENA , "<br>",
                  "<b>Radio de ausentismo: </b>", Mapa_NL$ausentismo , "<br>")


MD<- leaflet(Mapa_NL) %>%
  addProviderTiles("CartoDB.Positron") %>%
  addPolygons(color = "#444444" ,
              weight = 1, 
              smoothFactor = 0.5,
              opacity = 1.0,
              fillOpacity = 0.5,
              fillColor = pal(Mapa_NL$ganador),    # Color de llenado
              layerId = ~Mapa_NL$id,                  
              highlightOptions = highlightOptions(color = "white", weight = 2,
                                                  bringToFront = TRUE), 
              labelOptions = labelOptions(direction = "auto"),
              popup = popup) %>% 
  addLegend(position = "topright", pal = pal, values = ~Mapa_NL$ganador,
            title = "¿Quién va al Congreso?")  






